from fastapi import FastAPI, WebSocket
import asyncio
import httpx

app = FastAPI()

async def call_llm(prompt: str):
    async with httpx.AsyncClient() as client:
        response = await client.post("https://api.openai.com/v1/chat/completions", 
                                     headers={"Authorization": "Bearer YOUR_API_KEY"},
                                     json={
                                         "model": "gpt-4",
                                         "messages": [{"role": "user", "content": prompt}]
                                     })
        return response.json()['choices'][0]['message']['content']

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    prompts = ["Prompt 1", "Prompt 2", "Prompt 3"]

    async def send_response(prompt):
        response = await call_llm(prompt)
        await websocket.send_text(f"Response for '{prompt}': {response}")

    tasks = [send_response(p) for p in prompts]
    await asyncio.gather(*tasks)
    await websocket.close()
